function Spinner(){
    return (
        <div>
            <div className="d-flex justify-content-center mt-5">
                <div className="spinner-border"></div>
            </div>
        </div>
    )
}

export default Spinner;